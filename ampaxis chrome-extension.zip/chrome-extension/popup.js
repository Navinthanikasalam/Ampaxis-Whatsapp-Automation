// ============================================================
// AMPAXIS AMC SERVICES
// File: popup.js  (Chrome Extension — Popup Controller)
// ============================================================

'use strict';

// ─── DOM refs ────────────────────────────────────────────────
const toggleEl        = document.getElementById('toggle-enabled');
const toggleSubEl     = document.getElementById('toggle-sub');
const statusBadgeEl   = document.getElementById('status-badge');
const statSentEl      = document.getElementById('stat-sent');
const statFailedEl    = document.getElementById('stat-failed');
const statPendingEl   = document.getElementById('stat-pending');
const lastPollEl      = document.getElementById('last-poll');
const lastSentEl      = document.getElementById('last-sent');
const isProcessingEl  = document.getElementById('is-processing');
const pollDotEl       = document.getElementById('poll-dot');
const pollTextEl      = document.getElementById('poll-status-text');
const errorLogSection = document.getElementById('error-log-section');

// ─── Init ────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  await refreshUI();

  // Auto-refresh every 3 seconds while popup is open
  setInterval(refreshUI, 3000);
});

// ─── Event Listeners ────────────────────────────────────────

toggleEl.addEventListener('change', async () => {
  const enabled = toggleEl.checked;
  await chrome.runtime.sendMessage({ action: 'TOGGLE_ENABLED', enabled });
  updateToggleUI(enabled);
});

document.getElementById('btn-poll').addEventListener('click', async () => {
  const btn = document.getElementById('btn-poll');
  btn.disabled   = true;
  btn.textContent = '⏳ Polling...';

  await chrome.runtime.sendMessage({ action: 'POLL_NOW' });

  setTimeout(() => {
    btn.disabled    = false;
    btn.textContent = '🔄 Poll Queue Now';
    refreshUI();
  }, 2000);
});

document.getElementById('btn-wa').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://web.whatsapp.com', active: true });
});

document.getElementById('btn-clear-errors').addEventListener('click', async () => {
  await chrome.storage.local.set({ errorLog: [] });
  renderErrorLog([]);
});

// ─── UI Updater ──────────────────────────────────────────────

async function refreshUI() {
  try {
    const res = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });
    if (!res || !res.success) {
      console.warn('[Popup] GET_STATUS failed', res);
      return;
    }

    const d = res.data || {};

    // Toggle
    toggleEl.checked = !!d.isEnabled;
    updateToggleUI(d.isEnabled);

    // Stats
    statSentEl.textContent    = d.totalSent    ?? 0;
    statFailedEl.textContent  = d.totalFailed  ?? 0;
    statPendingEl.textContent = d.pendingCount ?? 0;

    // Info rows
    lastPollEl.textContent     = formatTime(d.lastPollAt);
    lastSentEl.textContent     = formatTime(d.lastSentAt);
    isProcessingEl.textContent = d.isProcessing ? '⚡ Yes' : 'No';

    // Poll dot
    if (d.isEnabled) {
      pollDotEl.className   = 'dot green';
      pollTextEl.textContent = 'Polling every 1 min...';
    } else {
      pollDotEl.className   = 'dot grey';
      pollTextEl.textContent = 'Automation disabled';
    }

    // Error log
    renderErrorLog(d.errorLog || []);

  } catch (err) {
    console.error('[Popup] refreshUI error:', err);
  }
}

function updateToggleUI(enabled) {
  if (enabled) {
    statusBadgeEl.textContent = '🟢 Active';
    statusBadgeEl.className   = 'badge green';
    toggleSubEl.textContent   = 'Automation is running';
  } else {
    statusBadgeEl.textContent = '🔴 Disabled';
    statusBadgeEl.className   = 'badge red';
    toggleSubEl.textContent   = 'Click to enable automation';
  }
}

function renderErrorLog(errors) {
  if (!errors || errors.length === 0) {
    errorLogSection.innerHTML = '<div class="no-log">No recent errors 👍</div>';
    return;
  }

  errorLogSection.innerHTML = errors.slice(0, 5).map(e =>
    `<div class="log-entry">
      <strong>${e.context}</strong>: ${e.msg}
      <br><span style="color:#6B7280;font-size:9px">${formatTime(e.time)}</span>
    </div>`
  ).join('');
}

function formatTime(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch (_) {
    return '—';
  }
}
