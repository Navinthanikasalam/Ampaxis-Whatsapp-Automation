// ============================================================
// AMPAXIS AMC SERVICES
// File: content.js  (Chrome Extension — Content Script)
// Purpose: Runs on WhatsApp Web, fills the message box, clicks
//          Send, and reports success/failure back to background.js
// Works for: Internship Automation + Job Recruitment Automation
// ============================================================

'use strict';

// ─── Selectors (WhatsApp Web 2024+) ──────────────────────────
// NOTE: WhatsApp Web's DOM has MULTIPLE contenteditable elements at once
// (search box, message box, caption box for media). Selectors are scoped
// to `footer` wherever possible so a fallback never grabs the wrong box.
const SEL = {
  SEND_BTN: [
    'footer button[aria-label="Send"]',
    'button[aria-label="Send"]',
    'footer button[data-testid="send"]',
    'footer [data-icon="send"]',
  ],
  MSG_BOX: [
    'footer div[contenteditable="true"][data-tab="10"]',
    'footer div[contenteditable="true"]',
    'footer div[contenteditable="plaintext-only"]',
    'footer div[role="textbox"]',
    'footer div[aria-label="Type a message"]',
    // Last-resort, unscoped fallbacks only if WhatsApp drops the footer landmark entirely:
    'div[contenteditable="true"][data-tab="10"]',
    'div[aria-label="Type a message"]',
  ],
  CHAT_PANEL: '#main',
  QR_CODE: 'div[data-testid="qr-code"]',
  INVALID_NUM: '[data-testid="confirm-popup"]',
};

const SEND_WAIT_MS = 2000;
const TIMEOUT_MS = 25000;
let lastHandledQueueId = null;
let lastHandledAt = 0;

function shouldHandleSend(queueId) {
  if (!queueId) return false;
  const now = Date.now();
  if (lastHandledQueueId === queueId && now - lastHandledAt < 10000) {
    log(`Skipping duplicate send request for ${queueId}`);
    return false;
  }
  lastHandledQueueId = queueId;
  lastHandledAt = now;
  return true;
}

// ─── Main ────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  (async function () {
    try {
      if (!msg || msg.action !== 'SEND_NOW') {
        sendResponse({ success: false, error: 'Unknown action' });
        return;
      }

      const currentSend = await getCurrentSend();
      if (!currentSend?.queueId) {
        sendResponse({ success: false, error: 'No current send task' });
        return;
      }

      if (!shouldHandleSend(currentSend.queueId)) {
        sendResponse({ success: true, skipped: true });
        return;
      }

      const success = await attemptSend(currentSend);
      sendResponse({ success: success });
      if (success) {
        reportSuccess(currentSend.queueId);
      } else {
        reportFailure('Send button not found or click failed', currentSend.queueId);
      }
    } catch (err) {
      log(`SEND_NOW error: ${err.message}`);
      sendResponse({ success: false, error: err.message });
    }
  })();
  return true;
});

// ─── Send Logic ──────────────────────────────────────────────
async function attemptSend(sendData) {
  try {
    const sendBtn = await waitForElement(SEL.SEND_BTN, TIMEOUT_MS);
    if (!sendBtn) {
      const popup = document.querySelector(SEL.INVALID_NUM);
      if (popup) {
        reportFailure('Phone number not on WhatsApp', sendData.queueId);
        return false;
      }
      return false;
    }

    await delay(800);

    const msgBox = await waitForElement(SEL.MSG_BOX, 5000);
    const messageText = String(sendData.message || '').trim();
    if (msgBox && messageText) {
      const currentText = normalizeText(msgBox);
      if (!currentText || currentText !== messageText) {
        log('Filling message box manually');
        await typeMessage(msgBox, messageText);
        await delay(500);
      }
    }

    await clickSendButton(sendBtn);
    return true;
  } catch (err) {
    log(`attemptSend error: ${err.message}`);
    return false;
  }
}

async function typeMessage(box, text) {
  if (!box) return;
  try {
    box.focus();

    if (typeof box.value === 'string') {
      box.value = text;
      box.dispatchEvent(new Event('input', { bubbles: true }));
      await delay(300);
      return;
    }

    if (box.isContentEditable) {
      box.innerHTML = '';
      box.textContent = text;
      box.dispatchEvent(new Event('input', { bubbles: true }));
      box.dispatchEvent(new Event('change', { bubbles: true }));
      await delay(300);
      return;
    }

    if (box.setRangeText) {
      box.setRangeText(text, 0, box.value.length || 0);
      box.dispatchEvent(new Event('input', { bubbles: true }));
      await delay(300);
    }
  } catch (err) {
    log(`typeMessage error: ${err.message}`);
  }
}

async function clickSendButton(btn) {
  try {
    if (!btn) return;
    btn.focus();
    if (typeof btn.click === 'function') {
      btn.click();
    } else {
      btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }
    await delay(1200);
  } catch (err) {
    log(`clickSendButton error: ${err.message}`);
  }
}

// ─── Report back to background ───────────────────────────────
function reportSuccess(queueId) {
  log(`✅ Reporting success: ${queueId}`);
  chrome.runtime.sendMessage({ action: 'WHATSAPP_SENT', queueId });
}

function reportFailure(reason, queueId) {
  log(`❌ Reporting failure: ${reason}`);
  chrome.runtime.sendMessage({ action: 'WHATSAPP_FAILED', queueId: queueId || null, reason });
}

// ─── Utilities ───────────────────────────────────────────────
function normalizeText(el) {
  try {
    return String(el && (el.innerText || el.textContent || el.value || '')).trim();
  } catch (_) {
    return '';
  }
}

function getCurrentSend() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(['currentSend'], (result) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(result && result.currentSend ? result.currentSend : null);
    });
  });
}

function findFirstMatch(selectors) {
  for (const s of selectors) {
    const el = document.querySelector(s);
    if (el) {
      log(`Matched selector: ${s}`);
      return el;
    }
  }
  return null;
}

function waitForElement(selectorOrSelectors, timeoutMs = 10000) {
  const selectors = Array.isArray(selectorOrSelectors) ? selectorOrSelectors : [selectorOrSelectors];
  return new Promise((resolve) => {
    const found = findFirstMatch(selectors);
    if (found) return resolve(found);

    const start = Date.now();
    const observer = new MutationObserver(() => {
      const match = findFirstMatch(selectors);
      if (match) {
        observer.disconnect();
        resolve(match);
      } else if (Date.now() - start > timeoutMs) {
        observer.disconnect();
        log(`No selector matched within ${timeoutMs}ms: ${selectors.join(', ')}`);
        resolve(null);
      }
    });

    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }

    setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeoutMs);
  });
}

function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function log(msg) { console.log(`[Ampaxis Content] ${msg}`); }
