#!/usr/bin/env python3
"""
Generate placeholder icons for the Shine Craft Chrome Extension.
Run: python3 generate_icons.py
Requires: Pillow  (pip install Pillow)
"""

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Installing Pillow...")
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow", "--quiet"])
    from PIL import Image, ImageDraw, ImageFont

import os

SIZES = [16, 48, 128]
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "icons")
os.makedirs(OUTPUT_DIR, exist_ok=True)

def make_icon(size):
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Background circle — brand blue
    margin = size // 8
    draw.ellipse([margin, margin, size - margin, size - margin],
                 fill=(29, 78, 216, 255))

    # Rocket emoji substitute — white "W" (WhatsApp style)
    font_size = int(size * 0.55)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()

    text = "W"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw   = bbox[2] - bbox[0]
    th   = bbox[3] - bbox[1]
    tx   = (size - tw) // 2 - bbox[0]
    ty   = (size - th) // 2 - bbox[1]
    draw.text((tx, ty), text, fill=(255, 255, 255, 255), font=font)

    path = os.path.join(OUTPUT_DIR, f"icon{size}.png")
    img.save(path)
    print(f"  Created: {path}")

print("Generating icons...")
for s in SIZES:
    make_icon(s)
print("Done! Icons saved to ./icons/")
